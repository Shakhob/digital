<?php

return array (
  0 =>
  array (
    'id' => 1,
    'translations' =>
    array (
      0 =>
      array (
        'post_id' => 1,
        'language' => 'de-DE',
        'title' => 'Post titel 1',
        'body' => 'Post inhalt 1',
      ),
      1 =>
      array (
        'post_id' => 1,
        'language' => 'en-US',
        'title' => 'Post title 1',
        'body' => 'Post body 1',
      ),
      2 =>
      array (
        'post_id' => 1,
        'language' => 'ru-RU',
        'title' => 'Заголовок поста 1',
        'body' => 'Тело поста 1',
      ),
    ),
  ),
  1 =>
  array (
    'id' => 2,
    'translations' =>
    array (
      0 =>
      array (
        'post_id' => 2,
        'language' => 'de-DE',
        'title' => 'Post titel 2',
        'body' => 'Post inhalt 2',
      ),
      1 =>
      array (
        'post_id' => 2,
        'language' => 'en-US',
        'title' => 'Post title 2',
        'body' => 'Post body 2',
      ),
      2 =>
      array (
        'post_id' => 2,
        'language' => 'ru-RU',
        'title' => 'Заголовок поста 2',
        'body' => 'Тело поста 2',
      ),
    ),
  ),
  2 =>
  array (
    'id' => 3,
    'translations' =>
    array (
      0 =>
      array (
        'post_id' => 3,
        'language' => 'de-DE',
        'title' => 'Post titel 3',
        'body' => 'Post inhalt 3',
      ),
      1 =>
      array (
        'post_id' => 3,
        'language' => 'en-US',
        'title' => 'Post title 3',
        'body' => 'Post body 3',
      ),
      2 =>
      array (
        'post_id' => 3,
        'language' => 'ru-RU',
        'title' => 'Заголовок поста 3',
        'body' => 'Тело поста 3',
      ),
    ),
  ),
);
